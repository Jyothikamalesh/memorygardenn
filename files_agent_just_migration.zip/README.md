# SOAP → REST Migration Agent Swarm

Multi-agent system for migrating SOAP repos to REST. 1:1 functional migration — not a refactoring.

Supports **C# (WCF/ASMX → ASP.NET Web API)** and **Java (JAX-WS/CXF/Spring WS → Spring Boot)**.

## Philosophy

The SOAP and REST repos should look and feel the same. Same operations, same types, same logic. The only difference is the protocol: XML/SOAP/WSDL becomes JSON/HTTP/Swagger.

- 1:1 operation mapping. No merging. No splitting. No renaming.
- Business logic ported line-for-line. Only framework-specific patterns replaced.
- Functionality retention is the only measure of success.

## Agent Structure

```
.claude/agents/
├── orchestrator/agent.md       ← Entry point. Runs the pipeline.
├── analyzer/agent.md           ← Reads SOAP repo. Extracts everything.
├── structure/agent.md          ← Maps SOAP → REST (1:1). Produces clear_structure.json.
├── validation-gate1/agent.md   ← 3 validators: is the mapping complete?
├── generator/agent.md          ← Produces REST repo + OpenAPI spec.
├── validation-gate2/agent.md   ← 4 validators: does it compile? is logic ported?
└── utils/agent.md              ← Shared schemas, detection script.
```

## Pipeline

```
SOAP Repo
    │
    ▼
 Analyzer ──▶ Structure ──▶ 🚦 Gate 1 ──▶ Generator ──▶ 🚦 Gate 2
                                │ fail                      │ fail
                                └─ retry (max 3)            └─ retry (max 3)
                                                                │ pass
                                                                ▼
                                                          REST Repo + Swagger
```

## Quick Start

```
Run the orchestrator agent to migrate this SOAP repo to REST.
Source: ./my-soap-service
```

## Validation

### Gate 1 — Is the mapping complete?
| Validator | Checks |
|---|---|
| `1to1_operation_coverage` | Every SOAP op → exactly 1 REST endpoint. No more, no less. |
| `type_coverage` | Every type preserved. All references resolve. |
| `business_logic_captured` | Source code of every method body is captured. |

### Gate 2 — Does the output work?
| Validator | Checks |
|---|---|
| `1to1_endpoint_coverage` | Every endpoint exists in generated controller code. |
| `schema_fidelity` | Field-by-field: every property in OpenAPI matches source types. |
| `build_compiles` | `dotnet build` or `mvn compile` succeeds. |
| `business_logic_ported` | Methods contain real logic, not TODO stubs. |

**No REST convention validators.** No style checks. No opinions on URL patterns, HTTP status codes, or naming. Just: is it complete, does it compile, does it work the same.

## Supported Stacks

| Source (SOAP) | Target (REST) |
|---|---|
| C# WCF | ASP.NET Web API (.NET 8) |
| C# ASMX | ASP.NET Web API (.NET 8) |
| Java JAX-WS | Spring Boot 3.x |
| Java Apache CXF | Spring Boot 3.x |
| Java Spring WS | Spring Boot 3.x |
