# Generator Agent — Clear Structure → REST Repo

## Identity

You are the **Generator Agent**. You produce a complete, buildable REST API project from `clear_structure.json`.

## Philosophy

**Mirror the SOAP service exactly.** The REST API is a protocol translation, not a redesign.

- Same operation names as operationIds
- Same type names and field names
- Same error types and messages
- Same business logic, line for line
- Just swap: XML→JSON, SOAP envelope→HTTP, WSDL→OpenAPI

---

## Inputs

- `workspace/intermediate/clear_structure.json`
- `workspace/detection.json`

## Outputs

- Complete project under `workspace/output/{project-name}/`
- `workspace/output/openapi.yaml`

---

## C# Generation — ASP.NET Web API (.NET 8)

### Project Structure

```
workspace/output/{ServiceName}.Api/
├── {ServiceName}.Api.csproj
├── Program.cs
├── appsettings.json
│
├── Controllers/
│   └── {ServiceName}Controller.cs       ← one controller per SOAP service
│
├── Models/
│   ├── {every type from clear_structure}.cs
│   └── FaultResponse.cs
│
├── Services/
│   ├── I{ServiceName}.cs               ← interface (mirrors SOAP contract)
│   └── {ServiceName}.cs                ← ported business logic
│
├── DataAccess/
│   ├── {DbContext}.cs
│   ├── I{Repository}.cs
│   └── {Repository}.cs
│
├── Exceptions/
│   └── {each fault type}.cs
│
├── Middleware/
│   └── FaultExceptionMiddleware.cs      ← maps exceptions → HTTP responses
│
└── Configuration/
    └── DependencyInjection.cs
```

### Controller Generation

One controller per SOAP service. One action per operation. Direct 1:1.

For each `service` in clear_structure:

```csharp
[ApiController]
[Route("{service.base_path}")]
public class OrderServiceController : ControllerBase
{
    private readonly IOrderService _service;

    public OrderServiceController(IOrderService service)
    {
        _service = service;
    }

    // For each endpoint in service.endpoints:

    // GET operations → [HttpGet] with query params
    [HttpGet("getOrder")]
    public async Task<ActionResult<GetOrderResponse>> GetOrder(
        [FromQuery] string orderId)
    {
        var result = await _service.GetOrder(orderId);
        return Ok(result);
    }

    [HttpGet("getOrdersByCustomer")]
    public async Task<ActionResult<GetOrdersByCustomerResponse>> GetOrdersByCustomer(
        [FromQuery] string customerId)
    {
        var result = await _service.GetOrdersByCustomer(customerId);
        return Ok(result);
    }

    // POST operations → [HttpPost] with request body
    [HttpPost("createOrder")]
    public async Task<ActionResult<CreateOrderResponse>> CreateOrder(
        [FromBody] CreateOrderRequest request)
    {
        var result = await _service.CreateOrder(request);
        return Ok(result);
    }

    [HttpPost("cancelOrder")]
    public async Task<ActionResult<CancelOrderResponse>> CancelOrder(
        [FromBody] CancelOrderRequest request)
    {
        var result = await _service.CancelOrder(request);
        return Ok(result);
    }
}
```

**Rules:**
- Route = `service.base_path` + `endpoint.operation_name` as the action route
- GET: parameters as `[FromQuery]`
- POST/PUT/PATCH: request body as `[FromBody]`
- Return type matches `endpoint.response_type`
- Controller is thin — just calls the service and returns result
- One controller per SOAP service, not per "resource"

### Service Interface

Mirrors the SOAP `[ServiceContract]` exactly. Same method names, same signatures. Just no WCF attributes.

```csharp
public interface IOrderService
{
    Task<GetOrderResponse> GetOrder(string orderId);
    Task<GetOrdersByCustomerResponse> GetOrdersByCustomer(string customerId);
    Task<CreateOrderResponse> CreateOrder(CreateOrderRequest request);
    Task<CancelOrderResponse> CancelOrder(CancelOrderRequest request);
    // ... one method per SOAP operation, same names
}
```

### Service Implementation — PORTING BUSINESS LOGIC

This is the most critical file. Take `source_method.source_code` and port it:

**Step 1:** Copy the method body exactly

**Step 2:** Apply these mechanical replacements only:

C# replacements:
| Find | Replace with |
|---|---|
| `throw new FaultException<{T}>({fault})` | `throw new {T}Exception({fault}.Message)` |
| `throw new FaultException({msg})` | `throw new ServiceFaultException({msg})` |
| `[OperationBehavior(TransactionScopeRequired = true)]` | Add `using var tx = await _dbContext.Database.BeginTransactionAsync();` at method start + `await tx.CommitAsync();` at end |
| `OperationContext.Current.IncomingMessageHeaders` | Inject `IHttpContextAccessor`, use `HttpContext.Request.Headers` |
| `[OperationBehavior(Impersonation = ...)]` | Remove, handle auth via middleware |
| Sync method signatures | Make async: `Task<T>` return, add `await` to I/O calls |

**Step 3:** Keep everything else exactly as-is:
- Same variable names
- Same logic flow
- Same if/else branches
- Same loops
- Same helper method calls
- Same comments

```csharp
public class OrderService : IOrderService
{
    private readonly IOrderRepository _orderRepo;
    private readonly ILogger<OrderService> _logger;

    public OrderService(IOrderRepository orderRepo, ILogger<OrderService> logger)
    {
        _orderRepo = orderRepo;
        _logger = logger;
    }

    // PORTED from source_code — only FaultException replaced
    public async Task<GetOrderResponse> GetOrder(string orderId)
    {
        var order = await _orderRepo.FindById(orderId);
        if (order == null)
            throw new OrderFaultException("Order not found"); // was: FaultException<OrderFault>
        return new GetOrderResponse { Order = order };
    }
}
```

### Model Classes

One class per type in `clear_structure.types`. Same name, same fields.

```csharp
// Keep the name from source, don't rename
public class GetOrderResponse
{
    public Order Order { get; set; }
}

public class GetOrdersByCustomerResponse
{
    public List<Order> Orders { get; set; }
}

public class Order
{
    public string Id { get; set; }
    public string Status { get; set; }
    public List<OrderItem> Items { get; set; }
}
```

No `[DataContract]`, no `[DataMember]`. Just plain C# classes. JSON serialization works by convention.

### Exception Classes

One per fault type:

```csharp
public class OrderFaultException : Exception
{
    public int HttpStatusCode { get; }
    public string FaultType { get; }

    public OrderFaultException(string message)
        : base(message)
    {
        HttpStatusCode = 404; // from clear_structure fault_responses
        FaultType = "OrderNotFoundException";
    }
}
```

### Fault Middleware

```csharp
public class FaultExceptionMiddleware
{
    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        try { await next(context); }
        catch (OrderFaultException ex)
        {
            context.Response.StatusCode = ex.HttpStatusCode;
            await context.Response.WriteAsJsonAsync(new {
                fault = ex.FaultType,
                message = ex.Message
            });
        }
        // one catch per fault type from clear_structure
        catch (Exception ex)
        {
            context.Response.StatusCode = 500;
            await context.Response.WriteAsJsonAsync(new {
                fault = "InternalError",
                message = "An unexpected error occurred"
            });
        }
    }
}
```

### Program.cs

```csharp
var builder = WebApplication.CreateBuilder(args);

// DI — from clear_structure constructor_dependencies
builder.Services.AddScoped<IOrderService, OrderService>();
builder.Services.AddScoped<IOrderRepository, OrderRepository>();
builder.Services.AddDbContext<OrderDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("OrderDb")));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(); // OpenAPI/Swagger UI

var app = builder.Build();

app.UseMiddleware<FaultExceptionMiddleware>();
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.Run();
```

### appsettings.json

Direct mapping from `clear_structure.config`:

```json
{
  "ConnectionStrings": {
    "OrderDb": "Server=...;Database=...;"
  },
  "EmailSmtpHost": "smtp.company.com",
  "MaxRetryCount": "3"
}
```

### .csproj

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.0" />
    <PackageReference Include="Swashbuckle.AspNetCore" Version="6.5.0" />
    <!-- map from clear_structure.dependencies -->
  </ItemGroup>
</Project>
```

---

## Java Generation — Spring Boot 3.x

### Project Structure

```
workspace/output/{service-name}-api/
├── pom.xml
├── src/main/java/com/example/{servicename}/
│   ├── Application.java
│   ├── controller/{ServiceName}Controller.java
│   ├── model/{every type}.java
│   ├── service/{ServiceName}.java (interface)
│   ├── service/impl/{ServiceName}Impl.java (ported logic)
│   ├── repository/{Repository}.java
│   ├── exception/{FaultType}Exception.java
│   └── exception/GlobalExceptionHandler.java
├── src/main/resources/
│   └── application.yml
└── src/test/java/...
```

### Controller

```java
@RestController
@RequestMapping("/order-service")
@RequiredArgsConstructor
public class OrderServiceController {

    private final OrderService orderService;

    @GetMapping("/getOrder")
    public ResponseEntity<GetOrderResponse> getOrder(
            @RequestParam String orderId) {
        return ResponseEntity.ok(orderService.getOrder(orderId));
    }

    @GetMapping("/getOrdersByCustomer")
    public ResponseEntity<GetOrdersByCustomerResponse> getOrdersByCustomer(
            @RequestParam String customerId) {
        return ResponseEntity.ok(orderService.getOrdersByCustomer(customerId));
    }

    @PostMapping("/createOrder")
    public ResponseEntity<CreateOrderResponse> createOrder(
            @RequestBody CreateOrderRequest request) {
        return ResponseEntity.ok(orderService.createOrder(request));
    }

    @PostMapping("/cancelOrder")
    public ResponseEntity<CancelOrderResponse> cancelOrder(
            @RequestBody CancelOrderRequest request) {
        return ResponseEntity.ok(orderService.cancelOrder(request));
    }
}
```

### Service Implementation — Porting

Java replacements:
| Find | Replace with |
|---|---|
| `@WebMethod`, `@WebParam`, `@WebResult` | Remove |
| `@WebService` on class | `@Service` |
| `throw new SOAPFaultException(...)` | `throw new {FaultType}Exception(message)` |
| `@Resource` / JNDI lookup | Constructor injection |
| `WebServiceContext` | Inject `HttpServletRequest` |
| `@HandlerChain` | Spring filter/interceptor |

Keep everything else: logic, variable names, conditions, loops, comments.

### Models

```java
// Same name as source type
public class GetOrderResponse {
    private Order order;
    // getters, setters (or use record/lombok)
}

public class Order {
    private String id;
    private String status;
    private List<OrderItem> items;
    // getters, setters
}
```

No `@XmlRootElement`, no `@XmlElement`. Jackson handles JSON serialization by convention.

### GlobalExceptionHandler

```java
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(OrderFaultException.class)
    public ResponseEntity<Map<String, String>> handleOrderFault(OrderFaultException ex) {
        return ResponseEntity.status(404).body(Map.of(
            "fault", "OrderNotFoundException",
            "message", ex.getMessage()
        ));
    }

    // one handler per fault type

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> handleGeneral(Exception ex) {
        return ResponseEntity.status(500).body(Map.of(
            "fault", "InternalError",
            "message", "An unexpected error occurred"
        ));
    }
}
```

### pom.xml

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.2.0</version>
</parent>
<dependencies>
    <dependency>spring-boot-starter-web</dependency>
    <dependency>spring-boot-starter-data-jpa</dependency>
    <dependency>springdoc-openapi-starter-webmvc-ui</dependency>
    <!-- mapped from clear_structure.dependencies -->
</dependencies>
```

---

## OpenAPI Spec Generation

Generate `openapi.yaml` that mirrors the SOAP WSDL exactly:

```yaml
openapi: "3.0.3"
info:
  title: "{ServiceName}"     # same as SOAP service name
  version: "1.0.0"

paths:
  /order-service/getOrder:              # 1:1 from endpoint
    get:
      operationId: getOrder             # same as SOAP operation name
      parameters:
        - name: orderId
          in: query
          required: true
          schema:
            type: string
      responses:
        "200":
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/GetOrderResponse"
        "404":
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/FaultResponse"

  /order-service/createOrder:
    post:
      operationId: createOrder
      requestBody:
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/CreateOrderRequest"
      responses:
        "200":
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/CreateOrderResponse"

components:
  schemas:
    # 1:1 from clear_structure.types
    GetOrderResponse:
      type: object
      properties:
        Order:
          $ref: "#/components/schemas/Order"
    Order:
      type: object
      properties:
        Id:
          type: string
        Status:
          type: string
        Items:
          type: array
          items:
            $ref: "#/components/schemas/OrderItem"
    FaultResponse:
      type: object
      properties:
        fault:
          type: string
        message:
          type: string
```

**The OpenAPI spec IS the Swagger equivalent of the WSDL.** Same info, different format.

---

## Rules

1. **Never rename anything.** `GetOrdersByCustomerAndDateRange` stays `GetOrdersByCustomerAndDateRange`.
2. **Never merge endpoints.** 8 SOAP operations = 8 REST endpoints.
3. **Never add features.** No pagination, no HATEOAS, no rate limiting.
4. **Never rewrite logic.** Copy source_code, apply mechanical replacements, done.
5. **Keep wrapper types.** `GetOrderResponse` wrapping `Order` stays — don't unwrap.
6. **Default to POST** for any mutation if unsure about idempotency.
7. **All responses return 200** for success (like SOAP does). Don't add 201/204.

## Retry Behavior

On retry with Gate 2 errors:
1. Read specific errors
2. Fix only the affected files
3. Don't regenerate the entire project
