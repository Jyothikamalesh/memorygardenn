# Utils — Shared Schemas & Detection

## Not Called Directly

This file contains shared conventions used by all agents.

---

## Detection Script

```python
#!/usr/bin/env python3
"""Detect language, framework, build system from a repo."""
import os, re, json

def detect_repo(repo_path: str) -> dict:
    result = {
        "language": None,
        "framework": None,
        "target_rest_framework": None,
        "project_files": [],
        "source_root": repo_path,
        "build_system": None,
        "sdk_version": None
    }

    files = _walk_files(repo_path)

    # --- C# ---
    csproj = [f for f in files if f.endswith('.csproj')]
    if csproj or any(f.endswith('.sln') for f in files):
        result["language"] = "csharp"
        result["build_system"] = "msbuild"
        result["project_files"] = csproj
        result["target_rest_framework"] = "aspnet-webapi"

        for cp in csproj:
            content = _read(os.path.join(repo_path, cp))
            m = re.search(r'<TargetFramework>(.*?)</TargetFramework>', content)
            if m: result["sdk_version"] = m.group(1)

        cs_content = " ".join(_read(os.path.join(repo_path, f)) for f in files if f.endswith('.cs'))[:50000]
        if '[ServiceContract]' in cs_content or any(f.endswith('.svc') for f in files):
            result["framework"] = "wcf"
        elif any(f.endswith('.asmx') for f in files):
            result["framework"] = "asmx"

    # --- Java ---
    has_pom = 'pom.xml' in files
    has_gradle = any('build.gradle' in f for f in files)
    if has_pom or has_gradle:
        result["language"] = "java"
        result["build_system"] = "maven" if has_pom else "gradle"
        result["target_rest_framework"] = "spring-boot"

        if has_pom:
            pom = _read(os.path.join(repo_path, "pom.xml"))
            if 'jaxws' in pom or 'javax.xml.ws' in pom: result["framework"] = "jaxws"
            elif 'cxf' in pom.lower(): result["framework"] = "cxf"
            elif 'spring-ws' in pom: result["framework"] = "springws"
            m = re.search(r'<java.version>(.*?)</java.version>', pom)
            if m: result["sdk_version"] = f"java{m.group(1)}"

        java_content = " ".join(
            _read(os.path.join(repo_path, f)) for f in files if f.endswith('.java')
        )[:50000]
        if '@WebService' in java_content:
            result["framework"] = result["framework"] or "jaxws"
        elif '@Endpoint' in java_content:
            result["framework"] = result["framework"] or "springws"

        if os.path.exists(os.path.join(repo_path, "src/main/java")):
            result["source_root"] = "src/main/java"

    return result

def _walk_files(path, max_depth=6):
    results = []
    skip = {'node_modules', '.git', 'bin', 'obj', 'target', 'build', '.idea', '.vs'}
    for root, dirs, files in os.walk(path):
        if root.replace(path, '').count(os.sep) > max_depth:
            dirs.clear(); continue
        dirs[:] = [d for d in dirs if d not in skip]
        for f in files:
            results.append(os.path.relpath(os.path.join(root, f), path))
    return results

def _read(path):
    try:
        with open(path, encoding='utf-8', errors='ignore') as f: return f.read()
    except: return ""
```

---

## Workspace Layout

```
workspace/
├── detection.json                     ← orchestrator writes
├── analysis/                          ← analyzer writes
│   ├── contracts.json
│   ├── operations.json
│   ├── types.json
│   ├── business_logic.json
│   ├── data_access.json
│   ├── config.json
│   └── dependencies.json
├── intermediate/                      ← structure agent writes
│   └── clear_structure.json
├── validation/                        ← gate agents write
│   ├── gate1_results.json
│   └── gate2_results.json
├── output/                            ← generator writes
│   ├── openapi.yaml
│   └── {generated project}/
└── migration_report.json              ← orchestrator writes
```

---

## Validation Result Schema

Both gates use:

```json
{
  "gate": "gate_1 | gate_2",
  "timestamp": "ISO 8601",
  "overall_status": "pass | fail",
  "validators": {
    "{name}": {
      "validator": "string",
      "status": "pass | fail | skip",
      "errors": [],
      "warnings": [],
      "fix_hints": []
    }
  },
  "total_errors": 0,
  "all_errors": [],
  "all_fix_hints": [],
  "recommendation": "pass | retry_phase_1 | retry_phase_2 | human_review"
}
```

## Error Feedback Schema (on retry)

```json
{
  "retry_attempt": 1,
  "source_gate": "gate_1 | gate_2",
  "previous_errors": [
    {
      "validator": "1to1_operation_coverage",
      "error": "SOAP operation 'UpdateOrderStatus' has no REST endpoint",
      "fix_hint": "Add endpoint for 'UpdateOrderStatus'",
      "affected_files": ["workspace/intermediate/clear_structure.json"]
    }
  ]
}
```

---

## The One Rule

**This is a migration. Not a refactoring.**

Every agent follows this: if SOAP has it, REST has it. Same name, same shape, same behavior. The only thing that changes is the protocol layer.
